<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F3IFH2z9vc9w7j5l',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/auth/(.*)(*:17)|/(.*)(*:29)|/api/v1\\.0/(?|auth/log(?|in(*:63)|out(*:73))|c(?|ategory/(?|list(*:100)|parent(*:114)|s(?|ave(*:129)|ingle(*:142))|update(*:157))|reditCompany/(?|s(?|ave(*:189)|ingle(*:202))|list(*:215)|update(*:229)|delete(*:243))|ompanySale/list(*:267))|t(?|ra(?|nsaction/s(?|ave(*:301)|ingle(*:314)|plit(*:326))|il\\-balance/get(*:350))|ank/(?|s(?|ave(*:373)|ingle(*:386))|list(*:399)|update(*:413)|delete(*:427)|get/nozzle(*:445)|re(?|ading/(?|s(?|ave(*:474)|ingle(*:487))|l(?|ist(*:503)|atest(*:516))|update(*:531)|delete(*:545))|fill/(?|s(?|ave(*:569)|ingle(*:582))|list(*:595)|update(*:609)|delete(*:623)))))|ba(?|lance\\-sheet/get(*:656)|nk/(?|s(?|ave(*:677)|ingle(*:690))|list(*:703)|update(*:717)|delete(*:731)))|p(?|ro(?|fit\\-and\\-loss/get(*:768)|duct/(?|type/list(*:793)|s(?|ave(*:808)|ingle(*:821))|list(*:834)|update(*:848)|d(?|elete(*:865)|ispenser(*:881))|get/tank(*:898)))|ay(?|able/get(*:921)|/order/(?|s(?|ave(*:946)|ingle(*:959))|l(?|ist(*:975)|atest(*:988))|update(*:1003)|delete(*:1018)))|osMachine/(?|s(?|ave(*:1049)|ingle(*:1063))|list(*:1077)|update(*:1092)|delete(*:1107)))|in(?|come\\-statement/get(*:1142)|voice/(?|generate(*:1168)|list(*:1181)|payment(*:1197)|d(?|elete(*:1215)|ownload/pdf(*:1235))|single(*:1251)))|receivable/get(*:1276)|ledger/get(*:1295)|d(?|ispenser/(?|s(?|ave(*:1327)|ingle(*:1341))|list(*:1355)|update(*:1370)|delete(*:1385)|reading/(?|s(?|ave(*:1412)|ingle(*:1426))|list(*:1440)|update(*:1455)|delete(*:1470)))|ashboard/get(*:1493))|nozzle/(?|s(?|ave(*:1520)|ingle(*:1534))|list(*:1548)|update(*:1563)|delete(*:1578)|reading/(?|s(?|ave(*:1605)|ingle(*:1619))|list(*:1633)|update(*:1648)|delete(*:1663)))|s(?|hift/sale/(?|s(?|ave(*:1698)|ingle(*:1712))|list(*:1726)|update(*:1741)|delete(*:1756)|getCategory(*:1776))|al(?|e/(?|s(?|ave(*:1803)|ingle(*:1817))|list(*:1831)|update(*:1846)|delete(*:1861))|ary/(?|s(?|earchEmployee(*:1895)|ave(*:1907)|ingle(*:1921))|list(*:1935)|update(*:1950)|delete(*:1965)|getCategory(*:1985))))|e(?|xpense/(?|s(?|ave(*:2018)|ingle(*:2032))|list(*:2046)|update(*:2061)|delete(*:2076))|mployee/(?|s(?|ave(*:2104)|ingle(*:2118))|list(*:2132)|update(*:2147)|delete(*:2162)))|vendor/(?|s(?|ave(*:2190)|ingle(*:2204))|list(*:2218)|update(*:2233)|delete(*:2248))))/?$}sDu',
    ),
    3 => 
    array (
      17 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Spa.Auth',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      29 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Spa.Dashboard',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      63 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZpjTifwmyrwvLpNL',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8jD9Ys4lU6mLpnAZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      100 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WwqLnavv4PzCoOjT',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TzWbQRd3bxt0jNxt',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ywgR2Su14neMjUHZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jjHVXNWZ7PD30Chj',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vu1kGgYlQ5XBZGLs',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      189 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sd9FxQZ7wTAxDthE',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      202 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1k3k6VYPz0Kt9heq',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      215 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vuLBjPD2pVACvlOG',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      229 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IzrVzUw8QK3nGymL',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      243 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lLnnA3mgCGqWqxE9',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      267 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h3Ydo4advXAmAeKu',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      301 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lnXIFmhOPZzsmKob',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      314 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CAAdObPguAYYSgbD',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bSV7IqgLtrnI7yOa',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IWer2P1f9Kal2bt0',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      373 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oGb0SSSUU56tGY97',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      386 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1FsEUd8QuGBrJc8j',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      399 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iD3MwTqBgCWHB1RB',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      413 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JwLnzmVA9QhB2aga',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      427 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::27HLIK7DIiP4ZEpO',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      445 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wQGj8mWF9oJnvSOc',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      474 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tAqyCD9pCWifHIlp',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      487 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0FuYk1UfBinp945S',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      503 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uPal4CV8ROoKtsnq',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      516 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::88pGCu3AcXSQrUe6',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      531 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NRgnTPUCUsaucuej',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      545 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SOddZ5xF4uI2m3y0',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      569 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6mpuMP2nTT1yZtLB',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      582 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SsdIEM5Mf2dUEvzk',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      595 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wIfQO5wyMbQnYcxv',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      609 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tE3gqDCgFaPSVPMz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      623 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l5DlG24sqh3kgSih',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      656 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KUGUIFR70C8CoX4H',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      677 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6tkUqEuc0AL7c3oZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      690 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rWGAkOVcKaoMAUWA',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      703 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0qDdgQ1hwMjXDnUX',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      717 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yrsRq8E7phxhXBAH',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      731 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ddt90pbzoiq9d6X8',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      768 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fnwsGFExc4DA6lrY',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      793 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2FlIfs6mkQ6fGxVX',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      808 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NS5RnmjjuWxeePja',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      821 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HCjPdCSNFxADAI9w',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      834 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9JPugCfsSKERNsPF',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      848 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ksYvxX2G4a1cHoDN',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      865 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AgSKJZLhhZqE6NrE',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      881 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wQNKyluodE9zDOAD',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      898 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PpgokYzaw32Patng',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      921 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RSugB8qYIAG126ms',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      946 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5tJsYRR1wtDVNGkk',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      959 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oQvTwXm4LVnUaf9B',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      975 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c838XKZZeFMWOlS1',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      988 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e8hOmSPG76xpc4FU',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1003 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pqE4odMVeDRnrsvJ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AqJHC3NjVctUGbER',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1049 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wqHWS6ELI6EJvJfG',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1063 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kMXHznBWvHUxAdPG',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1077 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U00AbDGvPOhuH0xv',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1092 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l1HvLYZDdEfWOivR',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nu8O53oWmroyByeC',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hEYPHHbKsfqiYDJ8',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1168 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iBziW4E36oRd9Z0m',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1181 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4YzfQDQtIDCa6sYM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1197 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f8Zo9YCwVgBvYcLz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1215 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZT1ilvbJ7UsIDzOz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tW02JZP3d9wwgNBC',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K0Jjr4steUUvMD2J',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1276 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PMr1g5HqheybSVTJ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1295 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8bxr8In5k839rE6W',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1327 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::miIb5bXg7PSGe0AD',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1341 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HEjh57ar3V9U9tW0',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1355 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iYy7t49w6CoYKSYl',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1370 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Whm3PdHydRsslixh',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1385 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3XkLXBKbGpWM6pKg',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1412 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l8o0TAH6AzitEscW',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5zRQB91MFlpkEawR',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1440 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2jtKU9eJLAEBIn0W',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1455 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dnov4P2kL9K2W5js',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1470 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5xlYsYg6gPmlDusQ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1493 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MDRdSkAYrb6pbJzo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1520 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::19C2E6eIi2VtGHke',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1534 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VnkL4KYudF8X8fyM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1548 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uRrHJp1lK7NBEIOs',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1563 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::913lPUfLsplnrbIP',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1578 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C0kzFNJBSm2Edms5',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1605 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UeCKwVODl1gLRKhu',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1619 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dT8G3NyGVT9TqEcy',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uLgJH6TNT0TWS7kM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1648 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dcZqR2JO99zml4Qm',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1663 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::23mW7rUzce1YbNuv',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1698 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HFQlBaWBcSvNTGFQ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1712 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LnVelkUudifsYBhw',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1726 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rvnQUL8dfh7SkNmw',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1741 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zpXq4VJRexyeFU6K',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1756 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6kSCkeatebzzYhia',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1776 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OVhGU5017zG8ZNz8',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1803 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rxnAqEHf9JomRKHe',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1817 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ENaC5XVjbDfaOns9',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1831 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UIFtMHkQl7pQ2pFK',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1846 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gnqe8O9eWUiTR6Jg',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1861 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HVBgdBkUmFS8kZOK',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1895 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a6DEcG5TlqBDFjFI',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1907 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YgKOGj3Cot8eX1MR',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1921 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nEewBqu26YULUZug',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1935 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NS1eSy5wxU7ZVlxq',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1950 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fhMFcqQmJWw6Myc5',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1965 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JryjdqCgHBNq0v4x',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1985 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pz1c3dXunoITPWXQ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2018 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y6dGaDiZeL2Oeuh7',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2032 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WweGeYnb4NPtCA2j',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2046 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mgbYjz0vCpPUQpry',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2061 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TIMOmqveXmIpZTeS',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2076 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CaZSyWe5U9epaavK',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ao0seJAgjFBsN6vl',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2118 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::icMoYUsi9dZMoH2r',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JAyy6cvr48FVSwYt',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0GUPZme8vspn7v8Q',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2162 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HiuwzlbxpqjZXZot',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2190 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yXJ5oTJw2OcckThI',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2204 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N67BgraaysHpXWiC',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6DGjObyXDTKXrhMm',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HWuJKsXE9nCiz2kX',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2248 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WFcwBndoBK7HYqww',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::F3IFH2z9vc9w7j5l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::F3IFH2z9vc9w7j5l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Spa.Auth' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'LoginCheck',
        ),
        'uses' => '\\App\\Http\\Controllers\\SpaController@index',
        'controller' => '\\App\\Http\\Controllers\\SpaController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'Spa.Auth',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Spa.Dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'LoginCheck',
        ),
        'uses' => '\\App\\Http\\Controllers\\SpaController@index',
        'controller' => '\\App\\Http\\Controllers\\SpaController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'Spa.Dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZpjTifwmyrwvLpNL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/auth/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::ZpjTifwmyrwvLpNL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8jD9Ys4lU6mLpnAZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/auth/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::8jD9Ys4lU6mLpnAZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WwqLnavv4PzCoOjT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@list',
        'controller' => 'App\\Http\\Controllers\\CategoryController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::WwqLnavv4PzCoOjT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TzWbQRd3bxt0jNxt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/parent',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@parent',
        'controller' => 'App\\Http\\Controllers\\CategoryController@parent',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::TzWbQRd3bxt0jNxt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ywgR2Su14neMjUHZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@save',
        'controller' => 'App\\Http\\Controllers\\CategoryController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::ywgR2Su14neMjUHZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jjHVXNWZ7PD30Chj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@single',
        'controller' => 'App\\Http\\Controllers\\CategoryController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::jjHVXNWZ7PD30Chj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vu1kGgYlQ5XBZGLs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@update',
        'controller' => 'App\\Http\\Controllers\\CategoryController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::Vu1kGgYlQ5XBZGLs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lnXIFmhOPZzsmKob' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/transaction/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@save',
        'controller' => 'App\\Http\\Controllers\\TransactionController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/transaction',
        'where' => 
        array (
        ),
        'as' => 'generated::lnXIFmhOPZzsmKob',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CAAdObPguAYYSgbD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/transaction/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@single',
        'controller' => 'App\\Http\\Controllers\\TransactionController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/transaction',
        'where' => 
        array (
        ),
        'as' => 'generated::CAAdObPguAYYSgbD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bSV7IqgLtrnI7yOa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/transaction/split',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@split',
        'controller' => 'App\\Http\\Controllers\\TransactionController@split',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/transaction',
        'where' => 
        array (
        ),
        'as' => 'generated::bSV7IqgLtrnI7yOa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KUGUIFR70C8CoX4H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balance-sheet/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceSheetController@get',
        'controller' => 'App\\Http\\Controllers\\BalanceSheetController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balance-sheet',
        'where' => 
        array (
        ),
        'as' => 'generated::KUGUIFR70C8CoX4H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fnwsGFExc4DA6lrY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/profit-and-loss/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfitLossController@get',
        'controller' => 'App\\Http\\Controllers\\ProfitLossController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/profit-and-loss',
        'where' => 
        array (
        ),
        'as' => 'generated::fnwsGFExc4DA6lrY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hEYPHHbKsfqiYDJ8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/income-statement/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\IncomeStatementController@get',
        'controller' => 'App\\Http\\Controllers\\IncomeStatementController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/income-statement',
        'where' => 
        array (
        ),
        'as' => 'generated::hEYPHHbKsfqiYDJ8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RSugB8qYIAG126ms' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/payable/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayableController@get',
        'controller' => 'App\\Http\\Controllers\\PayableController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/payable',
        'where' => 
        array (
        ),
        'as' => 'generated::RSugB8qYIAG126ms',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PMr1g5HqheybSVTJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/receivable/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ReceivableController@get',
        'controller' => 'App\\Http\\Controllers\\ReceivableController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/receivable',
        'where' => 
        array (
        ),
        'as' => 'generated::PMr1g5HqheybSVTJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IWer2P1f9Kal2bt0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/trail-balance/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TrailBalanceController@get',
        'controller' => 'App\\Http\\Controllers\\TrailBalanceController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/trail-balance',
        'where' => 
        array (
        ),
        'as' => 'generated::IWer2P1f9Kal2bt0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8bxr8In5k839rE6W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/ledger/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\LedgerController@get',
        'controller' => 'App\\Http\\Controllers\\LedgerController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/ledger',
        'where' => 
        array (
        ),
        'as' => 'generated::8bxr8In5k839rE6W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2FlIfs6mkQ6fGxVX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/type/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductTypeController@list',
        'controller' => 'App\\Http\\Controllers\\ProductTypeController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product/type',
        'where' => 
        array (
        ),
        'as' => 'generated::2FlIfs6mkQ6fGxVX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NS5RnmjjuWxeePja' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@save',
        'controller' => 'App\\Http\\Controllers\\ProductController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::NS5RnmjjuWxeePja',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9JPugCfsSKERNsPF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@list',
        'controller' => 'App\\Http\\Controllers\\ProductController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::9JPugCfsSKERNsPF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HCjPdCSNFxADAI9w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@single',
        'controller' => 'App\\Http\\Controllers\\ProductController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::HCjPdCSNFxADAI9w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ksYvxX2G4a1cHoDN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update',
        'controller' => 'App\\Http\\Controllers\\ProductController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::ksYvxX2G4a1cHoDN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AgSKJZLhhZqE6NrE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::AgSKJZLhhZqE6NrE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wQNKyluodE9zDOAD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/dispenser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@getDispenser',
        'controller' => 'App\\Http\\Controllers\\ProductController@getDispenser',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::wQNKyluodE9zDOAD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PpgokYzaw32Patng' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/get/tank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@getTank',
        'controller' => 'App\\Http\\Controllers\\ProductController@getTank',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::PpgokYzaw32Patng',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::miIb5bXg7PSGe0AD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@save',
        'controller' => 'App\\Http\\Controllers\\DispenserController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::miIb5bXg7PSGe0AD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iYy7t49w6CoYKSYl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@list',
        'controller' => 'App\\Http\\Controllers\\DispenserController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::iYy7t49w6CoYKSYl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HEjh57ar3V9U9tW0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@single',
        'controller' => 'App\\Http\\Controllers\\DispenserController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::HEjh57ar3V9U9tW0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Whm3PdHydRsslixh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@update',
        'controller' => 'App\\Http\\Controllers\\DispenserController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::Whm3PdHydRsslixh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3XkLXBKbGpWM6pKg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@delete',
        'controller' => 'App\\Http\\Controllers\\DispenserController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::3XkLXBKbGpWM6pKg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l8o0TAH6AzitEscW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingSave',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::l8o0TAH6AzitEscW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2jtKU9eJLAEBIn0W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingList',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::2jtKU9eJLAEBIn0W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5zRQB91MFlpkEawR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingSingle',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::5zRQB91MFlpkEawR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dnov4P2kL9K2W5js' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingUpdate',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::dnov4P2kL9K2W5js',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5xlYsYg6gPmlDusQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingDelete',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::5xlYsYg6gPmlDusQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::19C2E6eIi2VtGHke' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@save',
        'controller' => 'App\\Http\\Controllers\\NozzleController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::19C2E6eIi2VtGHke',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uRrHJp1lK7NBEIOs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@list',
        'controller' => 'App\\Http\\Controllers\\NozzleController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::uRrHJp1lK7NBEIOs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VnkL4KYudF8X8fyM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@single',
        'controller' => 'App\\Http\\Controllers\\NozzleController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::VnkL4KYudF8X8fyM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::913lPUfLsplnrbIP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@update',
        'controller' => 'App\\Http\\Controllers\\NozzleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::913lPUfLsplnrbIP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C0kzFNJBSm2Edms5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@delete',
        'controller' => 'App\\Http\\Controllers\\NozzleController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::C0kzFNJBSm2Edms5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UeCKwVODl1gLRKhu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingSave',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::UeCKwVODl1gLRKhu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uLgJH6TNT0TWS7kM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingList',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::uLgJH6TNT0TWS7kM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dT8G3NyGVT9TqEcy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingSingle',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::dT8G3NyGVT9TqEcy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dcZqR2JO99zml4Qm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingUpdate',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::dcZqR2JO99zml4Qm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::23mW7rUzce1YbNuv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingDelete',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::23mW7rUzce1YbNuv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HFQlBaWBcSvNTGFQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@save',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::HFQlBaWBcSvNTGFQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rvnQUL8dfh7SkNmw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@list',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::rvnQUL8dfh7SkNmw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LnVelkUudifsYBhw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@single',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::LnVelkUudifsYBhw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zpXq4VJRexyeFU6K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@update',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::zpXq4VJRexyeFU6K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6kSCkeatebzzYhia' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@delete',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::6kSCkeatebzzYhia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OVhGU5017zG8ZNz8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/getCategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@getCategory',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@getCategory',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::OVhGU5017zG8ZNz8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y6dGaDiZeL2Oeuh7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@save',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::y6dGaDiZeL2Oeuh7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mgbYjz0vCpPUQpry' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@list',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::mgbYjz0vCpPUQpry',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WweGeYnb4NPtCA2j' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@single',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::WweGeYnb4NPtCA2j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TIMOmqveXmIpZTeS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@update',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::TIMOmqveXmIpZTeS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CaZSyWe5U9epaavK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@delete',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::CaZSyWe5U9epaavK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oGb0SSSUU56tGY97' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@save',
        'controller' => 'App\\Http\\Controllers\\TankController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::oGb0SSSUU56tGY97',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iD3MwTqBgCWHB1RB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@list',
        'controller' => 'App\\Http\\Controllers\\TankController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::iD3MwTqBgCWHB1RB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1FsEUd8QuGBrJc8j' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@single',
        'controller' => 'App\\Http\\Controllers\\TankController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::1FsEUd8QuGBrJc8j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JwLnzmVA9QhB2aga' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@update',
        'controller' => 'App\\Http\\Controllers\\TankController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::JwLnzmVA9QhB2aga',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::27HLIK7DIiP4ZEpO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@delete',
        'controller' => 'App\\Http\\Controllers\\TankController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::27HLIK7DIiP4ZEpO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wQGj8mWF9oJnvSOc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/get/nozzle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@getNozzle',
        'controller' => 'App\\Http\\Controllers\\TankController@getNozzle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::wQGj8mWF9oJnvSOc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tAqyCD9pCWifHIlp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingSave',
        'controller' => 'App\\Http\\Controllers\\TankController@readingSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::tAqyCD9pCWifHIlp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uPal4CV8ROoKtsnq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingList',
        'controller' => 'App\\Http\\Controllers\\TankController@readingList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::uPal4CV8ROoKtsnq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0FuYk1UfBinp945S' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingSingle',
        'controller' => 'App\\Http\\Controllers\\TankController@readingSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::0FuYk1UfBinp945S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NRgnTPUCUsaucuej' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingUpdate',
        'controller' => 'App\\Http\\Controllers\\TankController@readingUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::NRgnTPUCUsaucuej',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SOddZ5xF4uI2m3y0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingDelete',
        'controller' => 'App\\Http\\Controllers\\TankController@readingDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::SOddZ5xF4uI2m3y0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::88pGCu3AcXSQrUe6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/latest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@latestReading',
        'controller' => 'App\\Http\\Controllers\\TankController@latestReading',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::88pGCu3AcXSQrUe6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6mpuMP2nTT1yZtLB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillSave',
        'controller' => 'App\\Http\\Controllers\\TankController@refillSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::6mpuMP2nTT1yZtLB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wIfQO5wyMbQnYcxv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillList',
        'controller' => 'App\\Http\\Controllers\\TankController@refillList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::wIfQO5wyMbQnYcxv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SsdIEM5Mf2dUEvzk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillSingle',
        'controller' => 'App\\Http\\Controllers\\TankController@refillSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::SsdIEM5Mf2dUEvzk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tE3gqDCgFaPSVPMz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillUpdate',
        'controller' => 'App\\Http\\Controllers\\TankController@refillUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::tE3gqDCgFaPSVPMz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l5DlG24sqh3kgSih' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillDelete',
        'controller' => 'App\\Http\\Controllers\\TankController@refillDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::l5DlG24sqh3kgSih',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6tkUqEuc0AL7c3oZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@save',
        'controller' => 'App\\Http\\Controllers\\BankController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::6tkUqEuc0AL7c3oZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0qDdgQ1hwMjXDnUX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@list',
        'controller' => 'App\\Http\\Controllers\\BankController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::0qDdgQ1hwMjXDnUX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rWGAkOVcKaoMAUWA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@single',
        'controller' => 'App\\Http\\Controllers\\BankController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::rWGAkOVcKaoMAUWA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yrsRq8E7phxhXBAH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@update',
        'controller' => 'App\\Http\\Controllers\\BankController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::yrsRq8E7phxhXBAH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ddt90pbzoiq9d6X8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@delete',
        'controller' => 'App\\Http\\Controllers\\BankController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::ddt90pbzoiq9d6X8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yXJ5oTJw2OcckThI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@save',
        'controller' => 'App\\Http\\Controllers\\VendorController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::yXJ5oTJw2OcckThI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6DGjObyXDTKXrhMm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@list',
        'controller' => 'App\\Http\\Controllers\\VendorController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::6DGjObyXDTKXrhMm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N67BgraaysHpXWiC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@single',
        'controller' => 'App\\Http\\Controllers\\VendorController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::N67BgraaysHpXWiC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HWuJKsXE9nCiz2kX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@update',
        'controller' => 'App\\Http\\Controllers\\VendorController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::HWuJKsXE9nCiz2kX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WFcwBndoBK7HYqww' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@delete',
        'controller' => 'App\\Http\\Controllers\\VendorController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::WFcwBndoBK7HYqww',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5tJsYRR1wtDVNGkk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@save',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::5tJsYRR1wtDVNGkk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::c838XKZZeFMWOlS1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@list',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::c838XKZZeFMWOlS1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oQvTwXm4LVnUaf9B' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@single',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::oQvTwXm4LVnUaf9B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pqE4odMVeDRnrsvJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@update',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::pqE4odMVeDRnrsvJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AqJHC3NjVctUGbER' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@delete',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::AqJHC3NjVctUGbER',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e8hOmSPG76xpc4FU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/latest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@latest',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@latest',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::e8hOmSPG76xpc4FU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rxnAqEHf9JomRKHe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@save',
        'controller' => 'App\\Http\\Controllers\\SaleController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::rxnAqEHf9JomRKHe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UIFtMHkQl7pQ2pFK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@list',
        'controller' => 'App\\Http\\Controllers\\SaleController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::UIFtMHkQl7pQ2pFK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ENaC5XVjbDfaOns9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@single',
        'controller' => 'App\\Http\\Controllers\\SaleController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::ENaC5XVjbDfaOns9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gnqe8O9eWUiTR6Jg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@update',
        'controller' => 'App\\Http\\Controllers\\SaleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::Gnqe8O9eWUiTR6Jg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HVBgdBkUmFS8kZOK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@delete',
        'controller' => 'App\\Http\\Controllers\\SaleController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::HVBgdBkUmFS8kZOK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sd9FxQZ7wTAxDthE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@save',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::Sd9FxQZ7wTAxDthE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vuLBjPD2pVACvlOG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@list',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::vuLBjPD2pVACvlOG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1k3k6VYPz0Kt9heq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@single',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::1k3k6VYPz0Kt9heq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IzrVzUw8QK3nGymL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@update',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::IzrVzUw8QK3nGymL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lLnnA3mgCGqWqxE9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@delete',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::lLnnA3mgCGqWqxE9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wqHWS6ELI6EJvJfG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@save',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::wqHWS6ELI6EJvJfG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U00AbDGvPOhuH0xv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@list',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::U00AbDGvPOhuH0xv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kMXHznBWvHUxAdPG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@single',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::kMXHznBWvHUxAdPG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l1HvLYZDdEfWOivR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@update',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::l1HvLYZDdEfWOivR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nu8O53oWmroyByeC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@delete',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::nu8O53oWmroyByeC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ao0seJAgjFBsN6vl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@save',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::Ao0seJAgjFBsN6vl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JAyy6cvr48FVSwYt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@list',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::JAyy6cvr48FVSwYt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::icMoYUsi9dZMoH2r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@single',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::icMoYUsi9dZMoH2r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0GUPZme8vspn7v8Q' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@update',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::0GUPZme8vspn7v8Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HiuwzlbxpqjZXZot' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@delete',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::HiuwzlbxpqjZXZot',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a6DEcG5TlqBDFjFI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/searchEmployee',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@searchEmployee',
        'controller' => 'App\\Http\\Controllers\\SalaryController@searchEmployee',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::a6DEcG5TlqBDFjFI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YgKOGj3Cot8eX1MR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@save',
        'controller' => 'App\\Http\\Controllers\\SalaryController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::YgKOGj3Cot8eX1MR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NS1eSy5wxU7ZVlxq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@list',
        'controller' => 'App\\Http\\Controllers\\SalaryController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::NS1eSy5wxU7ZVlxq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nEewBqu26YULUZug' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@single',
        'controller' => 'App\\Http\\Controllers\\SalaryController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::nEewBqu26YULUZug',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fhMFcqQmJWw6Myc5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@update',
        'controller' => 'App\\Http\\Controllers\\SalaryController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::fhMFcqQmJWw6Myc5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JryjdqCgHBNq0v4x' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@delete',
        'controller' => 'App\\Http\\Controllers\\SalaryController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::JryjdqCgHBNq0v4x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pz1c3dXunoITPWXQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/getCategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@getCategory',
        'controller' => 'App\\Http\\Controllers\\SalaryController@getCategory',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::pz1c3dXunoITPWXQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h3Ydo4advXAmAeKu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/companySale/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@getCompanySale',
        'controller' => 'App\\Http\\Controllers\\SaleController@getCompanySale',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/companySale',
        'where' => 
        array (
        ),
        'as' => 'generated::h3Ydo4advXAmAeKu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iBziW4E36oRd9Z0m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@generate',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@generate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::iBziW4E36oRd9Z0m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4YzfQDQtIDCa6sYM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@list',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::4YzfQDQtIDCa6sYM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f8Zo9YCwVgBvYcLz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/payment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@payment',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@payment',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::f8Zo9YCwVgBvYcLz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZT1ilvbJ7UsIDzOz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@delete',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::ZT1ilvbJ7UsIDzOz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K0Jjr4steUUvMD2J' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@single',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::K0Jjr4steUUvMD2J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tW02JZP3d9wwgNBC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/download/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@downloadPdf',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@downloadPdf',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::tW02JZP3d9wwgNBC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MDRdSkAYrb6pbJzo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dashboard/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@get',
        'controller' => 'App\\Http\\Controllers\\DashboardController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dashboard',
        'where' => 
        array (
        ),
        'as' => 'generated::MDRdSkAYrb6pbJzo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
