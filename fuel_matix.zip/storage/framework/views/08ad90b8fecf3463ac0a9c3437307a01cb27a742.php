<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="Fuelmatix" />
    <meta property="og:title" content="Fuelmatix" />
    <meta property="og:description" content="Fuelmatix" />
    <meta property="og:image" content="<?php echo e(asset('images/favicon.ico')); ?>" />
    <meta name="format-detection" content="telephone=no" />

    <title>FuelMatix</title>

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/favicon.ico')); ?>" />
    <link href="<?php echo e(asset('vendor/jquery-nice-select/css/nice-select.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

    <!-- Style css -->

    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/popup.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link href="<?php echo e(asset('vendor/jquery-nice-select/css/nice-select.css')); ?>" rel="stylesheet">

    <script src="https://kit.fontawesome.com/f1e7026320.js" crossorigin="anonymous"></script>

    <script src="">

    </script>
</head>

<body>

<div id="app">
    <app></app>
</div>

<script src="<?php echo e(asset('js/app.js?version=1.2')); ?>"></script>

<script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-nice-select/js/jquery.nice-select.min.js')); ?>"></script>
<script src='<?php echo e(asset('vendor/moment/moment.min.js')); ?>'></script>

<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>

<!-- Chart piety plugin files -->
<script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
<!-- Dashboard 1 -->
<script src="<?php echo e(asset('js/popup.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>

<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/dlabnav-init.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<!--==============pi chart cdn link up===========-->
<script src="<?php echo e(asset('js/plugins-init/chartjs-init.js')); ?>"></script>
<script src="<?php echo e(asset('js/print.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\xampp7.4\htdocs\fuelmatix\resources\views/index.blade.php ENDPATH**/ ?>