$(".segbar").segbar([

  {
    data: [
      { title: "Test 1", value: 56 },
      { title: "Test 2", value: 76 },
      { title: "Test 3", value: 73 },
      { title: "Test 4", value: 36 },
      { title: "Test 5", value: 90 },

      { title: "Test 6", value: 90 },

      { title: "Test 7", value: 66 },
      { title: "Test 7", value: 29 },
    ],
  },
]);
