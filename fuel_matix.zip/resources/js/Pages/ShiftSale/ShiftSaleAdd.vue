<template>
    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles">
                <ol class="breadcrumb align-items-center ">
                    <li class="breadcrumb-item active">
                        <router-link :to="{name: 'Dashboard'}">Home</router-link>
                    </li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Shift Sale</a></li>
                </ol>
            </div>
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Shift Sale Start</h4>
                        </div>
                        <form @submit.prevent="save">
                            <div class="card-body">
                                <div class="process-wrapper">
                                    <div id="progress-bar-container" v-if="listData.length > 0">
                                        <ul>
                                            <li class="step step01" :class="{'active': p.id == product_id}"
                                                v-for="(p, pIndex) in listData" @click="product_id = p.id; productIndex = pIndex; getProductDispenser()">
                                                <div class="step-inner">{{ p.name }}</div>
                                            </li>
                                        </ul>

                                        <div id="line">
                                            <div id="line-progress" :style="{'width': calculateLineProgress() + '%'}"></div>
                                        </div>
                                    </div>
                                    <div class="text-center" v-else>No Product Found</div>

                                    <div id="progress-content-section" v-if="listDispenser">
                                        <div class="section-content discovery active">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5 class="card-title">
                                                        {{ listDispenser.product_name }}</h5>
                                                </div>
                                                <div class="card-body">
                                                    <div class="row align-items-center text-start">
                                                        <div class="col-md-2">
                                                            <label class="form-label">
                                                                <p class="m-0">OIL Stock </p>
                                                            </label>

                                                        </div>
                                                        <div class="mb-3 col-md-2">
                                                            <label>Previous Reading </label>
                                                            <input disabled id="prReading"
                                                                   type="text" class="form-control"
                                                                   v-model="listDispenser.start_reading">
                                                        </div>
                                                        <div class="mb-3 col-md-2">
                                                            <label>Tank Refill </label>
                                                            <input type="text" class="form-control"  disabled
                                                                v-model="listDispenser.tank_refill">
                                                        </div>
                                                        <div class="mb-3 col-md-2">
                                                            <label>Final Reading </label>
                                                            <input id="frReading" @blur="disableInput('frReading')" v-if="listDispenser.status == 'end'"
                                                                type="text" class="form-control"  @click="enableInput('frReading')"
                                                                v-model="listDispenser.end_reading"
                                                                @input="calculateAmount">
                                                            <input class="form-control" value="0" v-if="listDispenser.status == 'start'" disabled>
                                                        </div>

                                                        <div class="mb-3 col-md-2">
                                                            <label>Consumption </label>
                                                            <input type="text" class="form-control" id="consumption" disabled  v-if="listDispenser.status == 'end'"
                                                                   v-model="listDispenser.consumption">
                                                            <input class="form-control" value="0" v-if="listDispenser.status == 'start'" disabled>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card" v-if="listDispenser.dispensers.length > 0"
                                                 v-for="(d, dIndex) in listDispenser.dispensers">
                                                <div class="card-header">
                                                    <h5 class="card-title">{{ d.dispenser_name }}</h5>
                                                </div>
                                                <div class="card-body" v-if="d.nozzle.length > 0">
                                                    <div class="row align-items-center text-start" v-for="(n, nIndex) in d.nozzle">
                                                        <div class=" col-md-2">
                                                            <label class="form-label">
                                                                <p class="m-0">{{ n.name }}</p>
                                                            </label>
                                                        </div>
                                                        <div class="mb-3 col-md-3">
                                                            <label>Previous Reading </label>
                                                            <input type="text" class="form-control" disabled
                                                                   v-model="n.start_reading">
                                                        </div>
                                                        <div class="mb-3 col-md-3">
                                                            <label>Final Reading </label>
                                                            <input type="text" class="form-control" @blur="disableInput('frReading'+nIndex+dIndex)"
                                                                   v-if="listDispenser.status == 'end'"
                                                                   v-model="n.end_reading" @click="enableInput('frReading'+nIndex+dIndex)"
                                                                   @input="calculateAmountNozzle(dIndex, nIndex) ">
                                                            <input class="form-control" value="0" v-if="listDispenser.status == 'start'" disabled>
                                                        </div>


                                                        <div class="mb-3 col-md-2">
                                                            <label>Consumption </label>
                                                            <input type="text" disabled class="form-control"   v-if="listDispenser.status == 'end'"
                                                                   v-model="n.consumption">
                                                            <input class="form-control" value="0" v-if="listDispenser.status == 'start'" disabled>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <template v-if="listDispenser.status != 'start'">
                                                <div class="col-sm-11 text-end mb-2">
                                                    <h4>Total sale: {{totalSale}} Liter</h4>
                                                    <h4>Total amount: {{totalAmount}} Tk</h4>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6"></div>
                                                    <div class="col-sm-6 text-end">
                                                        <div class="d-flex mb-3"  v-for="(category,index) in categories">
                                                            <select class="form-control me-3" style="max-width: 210px" v-model="category.category_id"
                                                                    @change="isDataExist(category.category_id, 'category_id', index, categories)" >
                                                                <option v-for="c in allAmountCategory" :value="c.id">{{c.name}}</option>
                                                            </select>
                                                            <div class="form-group">
                                                                <input class="form-control me-3"  style="max-width: 210px" type="number" v-model="category.amount" :id="'categories.'+index+'.amount'"
                                                                       @input="calculateValue(category.amount)"
                                                                       :name="'categories.'+index+'.amount'">
                                                                <div class="invalid-feedback"></div>
                                                            </div>

                                                            <button class="btn btn-primary"  style="height: 54px" v-if="index == 0" type="button" @click="addCategory">+</button>
                                                            <button class="btn btn-danger"  style="height: 54px"   v-else  type="button" @click="removeCategory(index)">
                                                                <i class="fa-solid fa-xmark"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6"></div>
                                                    <div class="col-sm-6">
                                                        <h4>Amount: {{isNaN(totalPaid) ? 0 : totalPaid}} Tk</h4>
                                                    </div>
                                                </div>
                                            </template>

                                        </div>
                                    </div>
                                    <div class="text-center" v-else>Please Select any product</div>
                                </div>
                                <div class="row" style="text-align: right;" v-if="product_id">
                                    <div class="mb-3 col-md-6">

                                    </div>
                                    <div class="mb-3 col-md-6">
                                        <button type="submit" class="btn btn-primary" v-if="!loading && listDispenser?.status == 'start'">Start</button>
                                        <button type="submit" class="btn btn-primary" v-if="!loading && listDispenser?.status == 'end'">End</button>
                                        <button type="button" class="btn btn-primary" v-if="loading">Submitting...</button>
                                        <router-link :to="{name: 'ShiftSaleList'}" type="button" class="btn btn-primary">Cancel</router-link>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import ApiService from "../../Services/ApiService";
import ApiRoutes from "../../Services/ApiRoutes";

export default {
    data() {
        return {
            loading: false,
            listData: [],
            listDispenser: null,
            product_id: '',
            productIndex: 0,
            totalSale: 0,
            totalAmount: 0,
            allAmountCategory: null,
            categories: [],
            totalPaid: 0,
        }
    },
    methods: {
        calculateValue: function (amount) {
            this.totalPaid = 0
            this.categories.map(v => {
                this.totalPaid += parseInt(v.amount)
            })
        },
        removeCategory: function(index) {
            this.categories.splice(index, 1);
        },
        addCategory: function() {
            this.categories.push({
                amount: '',
                category_id: ''
            });
        },
        getTotalSale: function () {
            this.totalSale = 0
            this.totalAmount = 0
            this.listDispenser.dispensers.map((dispenser) => {
                dispenser.nozzle.map((nozzle) => {
                    this.totalSale += nozzle.consumption
                    this.totalAmount += nozzle.amount
                })
            })
        },
        disableInput: function (id) {
            $('#'+id).prop('readonly', true);
        },
        enableInput: function (id) {
            $('#'+id).prop('readonly', false);
        },
        calculateLineProgress: function () {
            let progress = 100
            let eachProgress = Math.round(progress / (this.listData?.length - 1))
            return (eachProgress * this.productIndex)
        },
        calculateAmount: function () {
            if (this.isNumeric(this.listDispenser.end_reading)) {
                this.listDispenser.consumption = parseFloat(this.listDispenser.start_reading) - parseFloat(this.listDispenser.end_reading)
                this.listDispenser.amount = parseFloat(this.listDispenser.consumption ) * parseFloat(this.listDispenser.selling_price)
            } else {
                this.listDispenser.consumption = 0
                this.listDispenser.amount = 0
            }
        },
        calculateAmountNozzle: function (dIndex, nIndex) {
            if (this.isNumeric(this.listDispenser.dispensers[dIndex].nozzle[nIndex].end_reading)) {
                this.listDispenser.dispensers[dIndex].nozzle[nIndex].consumption = parseFloat(this.listDispenser.dispensers[dIndex].nozzle[nIndex].end_reading) - parseFloat(this.listDispenser.dispensers[dIndex].nozzle[nIndex].start_reading)
                this.listDispenser.dispensers[dIndex].nozzle[nIndex].amount = parseFloat(this.listDispenser.dispensers[dIndex].nozzle[nIndex].consumption) * parseFloat(this.listDispenser.selling_price)
            } else {
                this.listDispenser.dispensers[dIndex].nozzle[nIndex].consumption = 0
                this.listDispenser.dispensers[dIndex].nozzle[nIndex].amount = 0
            }
            this.getTotalSale()
        },
        getProduct: function () {
            ApiService.POST(ApiRoutes.ProductList, {limit: 5000, page: 1, order_mode: 'ASC'}, res => {
                this.TableLoading = false
                if (parseInt(res.status) === 200) {
                    this.listData = res.data.data;
                }
            });
        },
        getCategory: function () {
            this.categories = []
            ApiService.POST(ApiRoutes.ShiftSaleGetCategory, {}, res => {
                if (parseInt(res.status) === 200) {
                    this.allAmountCategory = res.data;
                    this.categories.push({
                        amount: '',
                        category_id: this.allAmountCategory[0].id
                    });
                }
            });
        },
        getProductDispenser: function () {
            this.totalSale = 0
            this.totalAmount = 0
            ApiService.POST(ApiRoutes.ProductDispenser, {product_id: this.product_id}, res => {
                this.TableLoading = false
                if (parseInt(res.status) === 200) {
                    this.listDispenser = res.data;
                    this.getCategory()
                }
                this.getTotalSale()
            });
        },
        save: function () {
            ApiService.ClearErrorHandler();
            this.loading = true
            this.listDispenser.categories = this.categories;
            if (this.listDispenser.status == 'end') {
                let totalCategoryAmount = 0
                this.listDispenser.categories.map(v => {
                    totalCategoryAmount += parseInt(v.amount)
                })
                if (this.totalAmount != totalCategoryAmount) {
                    this.loading = false
                    this.$toast.error('Please match the total amount and category list')
                    return
                }
            }
            ApiService.POST(ApiRoutes.ShiftSaleAdd, this.listDispenser, res => {
                this.loading = false
                if (parseInt(res.status) === 200) {
                    this.$toast.success(res.message);
                    if (this.listDispenser.status == 'start') {
                        this.$router.push({
                            name: 'ShiftSaleListStart'
                        })
                    } else {
                        this.$router.push({
                            name: 'ShiftSaleList'
                        })
                    }
                } else {
                    ApiService.ErrorHandler(res.errors);
                }
            });
        },
    },
    created() {
        this.getProduct()
    },
    mounted() {
        if (this.$route.query.product_id != undefined) {
            this.product_id = this.$route.query.product_id
            this.getProduct()
            this.getProductDispenser()
        }
        $('#dashboard_bar').text('Shift Sale Start')
    }
}
</script>

<style scoped>

</style>
