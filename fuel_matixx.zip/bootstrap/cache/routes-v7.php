<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dpv033UlAc1xkq0h',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/auth/(.*)(*:17)|/(.*)(*:29)|/api/v1\\.0/(?|auth/log(?|in(*:63)|out(*:73))|c(?|a(?|tegory/(?|list(*:103)|parent(*:117)|s(?|ave(*:132)|ingle(*:145))|update(*:160))|r/search(*:177))|reditCompany/(?|s(?|ave(*:209)|ingle(*:222))|list(*:235)|update(*:249)|delete(*:263))|ompany(?|Sale/list(*:290)|/s(?|ave(*:306)|ingle(*:319))|Bill/(?|list(*:340)|download(*:356))))|t(?|ra(?|nsaction/s(?|ave(*:392)|ingle(*:405)|plit(*:417))|il\\-balance/get(*:441))|ank/(?|s(?|ave(*:464)|ingle(*:477))|list(*:490)|update(*:504)|delete(*:518)|get(?|/nozzle(*:539)|Volume(*:553)|BstiChart(*:570))|byProduct(*:588)|re(?|ading/(?|s(?|ave(*:617)|ingle(*:630))|l(?|ist(*:646)|atest(*:659))|update(*:674)|delete(*:688))|fill/(?|s(?|ave(*:712)|ingle(*:725))|list(*:738)|update(*:752)|delete(*:766)))))|ba(?|lance(?|\\-sheet/get(*:802)|Transfer/(?|s(?|ave(*:829)|ingle(*:842))|list(*:855)|update(*:869)|approve(*:884)|delete(*:898)))|nk/(?|s(?|ave(*:921)|ingle(*:934))|list(*:947)|update(*:961)|delete(*:975)))|p(?|ro(?|fit\\-and\\-loss/get(*:1012)|duct/(?|type/list(*:1038)|s(?|ave(*:1054)|ingle(*:1068))|list(*:1082)|update(*:1097)|d(?|elete(*:1115)|ispenser(*:1132))|get/tank(*:1150)))|ay(?|able/get(*:1174)|/order/(?|s(?|ave(*:1200)|ingle(*:1214))|l(?|ist(*:1231)|atest(*:1245))|update(*:1261)|delete(*:1276)|quantity(*:1293)))|osMachine/(?|s(?|ave(*:1324)|ingle(*:1338))|list(*:1352)|update(*:1367)|delete(*:1382))|ermission/list(*:1406))|in(?|come\\-statement/get(*:1440)|voice/(?|g(?|enerate(*:1469)|lobal/payment(*:1491))|list(*:1505)|payment(*:1521)|d(?|elete(*:1539)|ownload/pdf(*:1559))|single(*:1575)))|r(?|e(?|ceivable/get(*:1606)|port/(?|dailyLog(?|(*:1634)|/export/pdf(*:1654))|sales(*:1669)))|ole/(?|list(*:1691)|s(?|ave(*:1707)|ingle(*:1721))|update(*:1737)|delete(*:1752)))|ledger/get(*:1773)|d(?|ispenser/(?|s(?|ave(*:1805)|ingle(*:1819))|list(*:1833)|update(*:1848)|delete(*:1863)|reading/(?|s(?|ave(*:1890)|ingle(*:1904))|list(*:1918)|update(*:1933)|delete(*:1948)))|ashboard/get(*:1971)|river/(?|s(?|ave(*:1996)|ingle(*:2010))|list(*:2024)|update(*:2039)|delete(*:2054)|amount(*:2069)))|nozzle/(?|s(?|ave(*:2097)|ingle(*:2111))|list(*:2125)|update(*:2140)|delete(*:2155)|reading/(?|s(?|ave(*:2182)|ingle(*:2196))|list(*:2210)|update(*:2225)|delete(*:2240)))|s(?|hift/sale/(?|s(?|ave(*:2275)|ingle(*:2289))|list(*:2303)|update(*:2318)|delete(*:2333)|getCategory(*:2353))|al(?|e/(?|s(?|ave(*:2380)|ingle(*:2394))|list(*:2408)|u(?|pdate(*:2426)|nauthorizedBill(?|(*:2453)|/transfer(*:2471)))|delete(*:2488))|ary/(?|s(?|earchEmployee(*:2522)|ave(*:2534)|ingle(*:2548))|list(*:2562)|update(*:2577)|delete(*:2592)|getCategory(*:2612)|print(*:2626))))|e(?|xpense/(?|s(?|ave(*:2659)|ingle(*:2673))|list(*:2687)|update(*:2702)|delete(*:2717)|approve(*:2733))|mployee/(?|s(?|ave(*:2761)|ingle(*:2775))|list(*:2789)|update(*:2804)|delete(*:2819)))|v(?|endor/(?|s(?|ave(*:2850)|ingle(*:2864))|list(*:2878)|update(*:2893)|delete(*:2908))|oucher/(?|save(*:2932)|list(*:2945)))|user/(?|s(?|ave(*:2971)|ingle(*:2985))|list(*:2999)|update(*:3014)|delete(*:3029))|fuelAdjustment/(?|s(?|ave(*:3064)|ingle(*:3078))|list(*:3092)|update(*:3107)|delete(*:3122))))/?$}sDu',
    ),
    3 => 
    array (
      17 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Spa.Auth',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      29 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'Spa.Dashboard',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      63 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yu9jkkXVtKLzw7UU',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ikiqDnYxmBAeNej7',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      103 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j10Ua7Ft4FgGgBpW',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      117 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NosOJ4ZWQldg05Ua',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DKdEkfHwu1rkeYHr',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g8QtAYutYI7NSlBP',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      160 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zJyUk14wLBaQz3en',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      177 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rgSCW9YyFFdkZi6E',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      209 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L7GLlpjDsCnjnlRg',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      222 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AZYswNQ2koWaJLbI',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IeQ2FnGPLbhhfwVe',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SFs1Hl2oGgIWOIbH',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      263 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7p9G57Da2EtEms08',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      290 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ucK4ll9DBz6noEPo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      306 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eHXkzpmZP1C6IvUe',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      319 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yUlIKpGEHFPZz5sh',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6xzY4IXn3vRfUV1X',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      356 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vqv9VtFOqq1Qumqs',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0hjRmtWoiMHJKYLJ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      405 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kKsZyHIXpbUBTIJS',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      417 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HzS1z6gtyal1znWQ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      441 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hzaokZwC1SNeu9tz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      464 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RisnU6KgD87CSs8H',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xB4xkqBsb5Ks9gg2',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bd3zQXvhnU9Vxvt7',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      504 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9Y6J3RGoh2pk6xuN',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      518 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qKi6sHu9mQhdlluv',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      539 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xtbAwi5aFOS2wFyR',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      553 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VWmwmpANPF0UhoMZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      570 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i45VQXaTeWUtBeOG',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      588 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lffeCqUjUNGFR5B3',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      617 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kMzZ1xhP7BhEoYvO',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      630 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VQUuapKgzcBHVi6N',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      646 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h3JzMiEp6sFtvP5c',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      659 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IlP9Oi9TobRdN5Wx',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      674 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kE9h50lLJzRWsGUq',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      688 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lBRXpZ7YctkxddO8',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      712 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AQtcQKodEPZdZ6Vt',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      725 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lcSgK4Fmy8wRWRpa',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      738 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XZ4ox848EPLzOhRm',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      752 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tU8hJurInd7vH6ZI',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      766 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m27RRjP6h272DLjq',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KnLsjE2OeLeRjKfZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      829 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l5ZmhlhJLvVGka85',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      842 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0rES6xCZDB7ON9wH',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      855 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m9D1Hmy7SMeR5EGY',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      869 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mQluNUlPgARNjwaR',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      884 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fUr9fvL5M5sCjLrn',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      898 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JcGs6LbEf7if5Fen',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      921 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0K6dTaiexlYlqegM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      934 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jXbhMbGRtMjoonHw',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      947 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1pEzM5tD76mATFpN',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      961 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hZbLMpwl2TyH5jR4',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      975 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QeDgLTvSrwBhBRVi',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1012 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nqQrZsOtgKnIbBWj',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1038 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MEUy7HNB5fy6X8M9',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1054 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MY5GmnuJppKTn7qZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1068 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AMgSy1bG2AgvqIJZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1082 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9HnYxZ2EwS1yX3jz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1097 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3NJ3Ptr0TnqSmHLn',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XMJmUC2NCysK9RYG',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1132 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xPC9Pow7LkKan6Nd',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1150 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zAeQ5K6LMEJVYPZF',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1174 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aQylEkAYPdN87Sng',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1200 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::StbLYI1Y69AwfTYo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1214 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IAXFKnMS3OJ9bLof',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1231 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::274yFdXhqvzgmucT',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1245 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uiSkz7R0nmCj2KM3',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1261 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W97Ko5Kb9ATvpxIB',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1276 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::orYIXuTpfgtzuudD',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1293 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8B6WA6jf7PVBVmkl',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1324 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MO1cEwGRUzybTG5B',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1338 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d3fwDLFSQLd1eJcc',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1352 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MElopi6dtTyzBCCE',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1367 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NEQrIqrg1GhTHHeW',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1382 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8qoCvgCX1a1PE6iT',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1406 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::elcGY3BfF6lVXRdP',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1440 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lwdrxqOKtuZuSoMg',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1469 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7PQpt26EOSHbJNvy',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1491 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wq8xaK5VxWMfPSTI',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1505 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Kq5RRfHoayOjjCpk',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0zhX4XquCiSUZqmu',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1539 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IHSchNIrSLmuMqdD',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1559 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B0ygOp889vhmr8fk',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1575 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7XKFZ62LFtnPx1nV',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1606 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lg7HD1pfj1Fyhwgo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1634 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZHXtmCftTVSJcYoS',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0zq2RbyebbKufirb',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1669 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RAyMqnZjEw0CU6v7',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2Bx4dKv92QYThKgm',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1707 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LW30pAMpuNsSCKzP',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1721 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yc9CnpVieVCKfbEo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1737 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zaKtlNGwa7dnp5AY',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1752 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RhmBDGvswnRix2zf',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1773 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::23sSG0b2opLYTyeM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1805 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1GlDfcn0W4gIyMhC',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1819 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PfHz090VJUgZRilf',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1833 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1zwQeJ8aKhwNU3NF',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1848 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QmnMSOgMZMMtdRU0',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1863 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W1q0B85oGoVw74PQ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1890 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dly94zEHdJjAol2t',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1904 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v4pwQIw2T3T4QIsL',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1918 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OjVIftNTarJ91dCN',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1933 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i3ddomukbi51pXzq',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rALEFSnDu3WQqsWA',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1971 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MWJILjmHxRg5Xvj3',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1996 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nnDdm4hrcKVKFFmz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2010 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7YWVpq6b1twuhawh',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2024 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dnnar7wL6jdXWIOH',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2039 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DdLBM61UcV4yKeXb',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2054 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2gFvFSS7b3Vs8NeL',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2069 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dXk3PgYHgNRlQyE4',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2097 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mlHC5QL55fzmVtWw',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2111 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MxlCpu1g7B7yBsqS',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2125 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A6fm9VM0YnE5Egdx',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2140 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r0jwhxROW5UwMDle',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2155 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZyikyGeit49pe2fX',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2182 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iRfHCLbCmh4fAInT',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2196 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zyfwLcijoRHaVJPZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2210 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VU7hFtjFrvPmIFCR',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2225 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lFz1Ra4cb6B3lBGu',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2240 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iyUlkwvcI3YLsh30',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2275 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dm1wiCEtmIPLDPPV',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h90zdpZDnlKcAQDa',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2303 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0UMzddN0BNaWJRuz',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2318 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ca3YM3Wn14Pq7euR',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2333 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bFokTdKblgFucunB',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2353 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aWJeHZXSOf7Zek4l',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2380 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xf60intCZABXF4q6',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2394 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FAAcpvC6eAZYU8vy',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2408 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dHfdDG3hWkQrmVMb',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::46PzbGgTE8YPlYKx',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::adYGzTAIafTUAEW1',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2471 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RHv1UJxXh5OlYN8z',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2488 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4ap1iycp3KBnXW9p',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sGhN5LBjAuhGH8Wy',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2534 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KuhWOyskjnBXqFkg',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2548 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gR8sjttAUdcnZXET',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2562 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MrYa8ZSbqoI1vsTL',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2577 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0bBw2R7uumrI7PUm',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2592 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QGNVh5oCb2Et39kr',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2612 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y1DU2pHmOn2txhkD',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2626 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RHZ17fk9gvFVEQUK',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2659 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3zwD6P69zdIqsNt5',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2673 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oFZUSK26g6JlZh0I',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2687 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LOkZXiDpJmHhFauL',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2702 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hIG4UNFzgm196m4O',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2717 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DpUuxuFSaijxcUw9',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2733 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tMAVmXrwfioIJqgO',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2761 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8Z9CZNw6sQEj5ozG',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2775 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tVUbiXRDIuul47Ci',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2789 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FBa3WqXlxoRzze5U',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e9t4sNPHJeogSHTg',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2819 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t7GTBqrtC10bHeVC',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2850 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cYixQitSbtBqr5yv',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2864 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mYjSJJLSrWDO9CTM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2878 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KaXLrgNT0Mt3lS9U',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2893 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4gB4cxtQWxGtT8o9',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2908 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hXaIg4cg1aMDjHDZ',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jwjEUwbyO0hugrmv',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2945 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KR4ONfReMZwSaU0s',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2971 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gEk6XaUsrS1cQRMB',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2985 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7GWeDUzxwdiaJCzM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2999 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6XbFnPxEhfvLvbgC',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3014 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OCGChP3Ex4uBgAy6',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3029 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IdGg0CKZPxxU3WDM',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3064 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PartApB4rw0EicWb',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3078 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M97c1Em4cjKc3aPw',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3092 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eSlJSUek5NFw863j',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3107 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TcgV60NYawjbxAZN',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3122 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Zq4IqrJlsoCa41G6',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::Dpv033UlAc1xkq0h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::Dpv033UlAc1xkq0h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Spa.Auth' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'auth/{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'LoginCheck',
        ),
        'uses' => '\\App\\Http\\Controllers\\SpaController@index',
        'controller' => '\\App\\Http\\Controllers\\SpaController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'Spa.Auth',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'Spa.Dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'LoginCheck',
        ),
        'uses' => '\\App\\Http\\Controllers\\SpaController@index',
        'controller' => '\\App\\Http\\Controllers\\SpaController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'Spa.Dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yu9jkkXVtKLzw7UU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/auth/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::yu9jkkXVtKLzw7UU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ikiqDnYxmBAeNej7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/auth/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::ikiqDnYxmBAeNej7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j10Ua7Ft4FgGgBpW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@list',
        'controller' => 'App\\Http\\Controllers\\CategoryController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::j10Ua7Ft4FgGgBpW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NosOJ4ZWQldg05Ua' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/parent',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@parent',
        'controller' => 'App\\Http\\Controllers\\CategoryController@parent',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::NosOJ4ZWQldg05Ua',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DKdEkfHwu1rkeYHr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@save',
        'controller' => 'App\\Http\\Controllers\\CategoryController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::DKdEkfHwu1rkeYHr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g8QtAYutYI7NSlBP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@single',
        'controller' => 'App\\Http\\Controllers\\CategoryController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::g8QtAYutYI7NSlBP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zJyUk14wLBaQz3en' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/category/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CategoryController@update',
        'controller' => 'App\\Http\\Controllers\\CategoryController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/category',
        'where' => 
        array (
        ),
        'as' => 'generated::zJyUk14wLBaQz3en',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0hjRmtWoiMHJKYLJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/transaction/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@save',
        'controller' => 'App\\Http\\Controllers\\TransactionController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/transaction',
        'where' => 
        array (
        ),
        'as' => 'generated::0hjRmtWoiMHJKYLJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kKsZyHIXpbUBTIJS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/transaction/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@single',
        'controller' => 'App\\Http\\Controllers\\TransactionController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/transaction',
        'where' => 
        array (
        ),
        'as' => 'generated::kKsZyHIXpbUBTIJS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HzS1z6gtyal1znWQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/transaction/split',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@split',
        'controller' => 'App\\Http\\Controllers\\TransactionController@split',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/transaction',
        'where' => 
        array (
        ),
        'as' => 'generated::HzS1z6gtyal1znWQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KnLsjE2OeLeRjKfZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balance-sheet/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceSheetController@get',
        'controller' => 'App\\Http\\Controllers\\BalanceSheetController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balance-sheet',
        'where' => 
        array (
        ),
        'as' => 'generated::KnLsjE2OeLeRjKfZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nqQrZsOtgKnIbBWj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/profit-and-loss/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProfitLossController@get',
        'controller' => 'App\\Http\\Controllers\\ProfitLossController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/profit-and-loss',
        'where' => 
        array (
        ),
        'as' => 'generated::nqQrZsOtgKnIbBWj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lwdrxqOKtuZuSoMg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/income-statement/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\IncomeStatementController@get',
        'controller' => 'App\\Http\\Controllers\\IncomeStatementController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/income-statement',
        'where' => 
        array (
        ),
        'as' => 'generated::lwdrxqOKtuZuSoMg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aQylEkAYPdN87Sng' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/payable/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayableController@get',
        'controller' => 'App\\Http\\Controllers\\PayableController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/payable',
        'where' => 
        array (
        ),
        'as' => 'generated::aQylEkAYPdN87Sng',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lg7HD1pfj1Fyhwgo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/receivable/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ReceivableController@get',
        'controller' => 'App\\Http\\Controllers\\ReceivableController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/receivable',
        'where' => 
        array (
        ),
        'as' => 'generated::lg7HD1pfj1Fyhwgo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hzaokZwC1SNeu9tz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/trail-balance/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TrailBalanceController@get',
        'controller' => 'App\\Http\\Controllers\\TrailBalanceController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/trail-balance',
        'where' => 
        array (
        ),
        'as' => 'generated::hzaokZwC1SNeu9tz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::23sSG0b2opLYTyeM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/ledger/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\LedgerController@get',
        'controller' => 'App\\Http\\Controllers\\LedgerController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/ledger',
        'where' => 
        array (
        ),
        'as' => 'generated::23sSG0b2opLYTyeM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MEUy7HNB5fy6X8M9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/type/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductTypeController@list',
        'controller' => 'App\\Http\\Controllers\\ProductTypeController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product/type',
        'where' => 
        array (
        ),
        'as' => 'generated::MEUy7HNB5fy6X8M9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MY5GmnuJppKTn7qZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@save',
        'controller' => 'App\\Http\\Controllers\\ProductController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::MY5GmnuJppKTn7qZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9HnYxZ2EwS1yX3jz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@list',
        'controller' => 'App\\Http\\Controllers\\ProductController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::9HnYxZ2EwS1yX3jz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AMgSy1bG2AgvqIJZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@single',
        'controller' => 'App\\Http\\Controllers\\ProductController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::AMgSy1bG2AgvqIJZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3NJ3Ptr0TnqSmHLn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update',
        'controller' => 'App\\Http\\Controllers\\ProductController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::3NJ3Ptr0TnqSmHLn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XMJmUC2NCysK9RYG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::XMJmUC2NCysK9RYG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xPC9Pow7LkKan6Nd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/dispenser',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@getDispenser',
        'controller' => 'App\\Http\\Controllers\\ProductController@getDispenser',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::xPC9Pow7LkKan6Nd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zAeQ5K6LMEJVYPZF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/product/get/tank',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@getTank',
        'controller' => 'App\\Http\\Controllers\\ProductController@getTank',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/product',
        'where' => 
        array (
        ),
        'as' => 'generated::zAeQ5K6LMEJVYPZF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1GlDfcn0W4gIyMhC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@save',
        'controller' => 'App\\Http\\Controllers\\DispenserController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::1GlDfcn0W4gIyMhC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1zwQeJ8aKhwNU3NF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@list',
        'controller' => 'App\\Http\\Controllers\\DispenserController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::1zwQeJ8aKhwNU3NF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PfHz090VJUgZRilf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@single',
        'controller' => 'App\\Http\\Controllers\\DispenserController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::PfHz090VJUgZRilf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QmnMSOgMZMMtdRU0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@update',
        'controller' => 'App\\Http\\Controllers\\DispenserController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::QmnMSOgMZMMtdRU0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::W1q0B85oGoVw74PQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@delete',
        'controller' => 'App\\Http\\Controllers\\DispenserController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser',
        'where' => 
        array (
        ),
        'as' => 'generated::W1q0B85oGoVw74PQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dly94zEHdJjAol2t' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingSave',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::dly94zEHdJjAol2t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OjVIftNTarJ91dCN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingList',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::OjVIftNTarJ91dCN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v4pwQIw2T3T4QIsL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingSingle',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::v4pwQIw2T3T4QIsL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i3ddomukbi51pXzq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingUpdate',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::i3ddomukbi51pXzq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rALEFSnDu3WQqsWA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dispenser/reading/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DispenserController@readingDelete',
        'controller' => 'App\\Http\\Controllers\\DispenserController@readingDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dispenser/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::rALEFSnDu3WQqsWA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mlHC5QL55fzmVtWw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@save',
        'controller' => 'App\\Http\\Controllers\\NozzleController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::mlHC5QL55fzmVtWw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A6fm9VM0YnE5Egdx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@list',
        'controller' => 'App\\Http\\Controllers\\NozzleController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::A6fm9VM0YnE5Egdx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MxlCpu1g7B7yBsqS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@single',
        'controller' => 'App\\Http\\Controllers\\NozzleController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::MxlCpu1g7B7yBsqS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r0jwhxROW5UwMDle' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@update',
        'controller' => 'App\\Http\\Controllers\\NozzleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::r0jwhxROW5UwMDle',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZyikyGeit49pe2fX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@delete',
        'controller' => 'App\\Http\\Controllers\\NozzleController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle',
        'where' => 
        array (
        ),
        'as' => 'generated::ZyikyGeit49pe2fX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iRfHCLbCmh4fAInT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingSave',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::iRfHCLbCmh4fAInT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VU7hFtjFrvPmIFCR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingList',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::VU7hFtjFrvPmIFCR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zyfwLcijoRHaVJPZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingSingle',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::zyfwLcijoRHaVJPZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lFz1Ra4cb6B3lBGu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingUpdate',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::lFz1Ra4cb6B3lBGu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iyUlkwvcI3YLsh30' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/nozzle/reading/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\NozzleController@readingDelete',
        'controller' => 'App\\Http\\Controllers\\NozzleController@readingDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/nozzle/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::iyUlkwvcI3YLsh30',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dm1wiCEtmIPLDPPV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@save',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::Dm1wiCEtmIPLDPPV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0UMzddN0BNaWJRuz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@list',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::0UMzddN0BNaWJRuz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h90zdpZDnlKcAQDa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@single',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::h90zdpZDnlKcAQDa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ca3YM3Wn14Pq7euR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@update',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::Ca3YM3Wn14Pq7euR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bFokTdKblgFucunB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@delete',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::bFokTdKblgFucunB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aWJeHZXSOf7Zek4l' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/shift/sale/getCategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ShiftSaleController@getCategory',
        'controller' => 'App\\Http\\Controllers\\ShiftSaleController@getCategory',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/shift/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::aWJeHZXSOf7Zek4l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3zwD6P69zdIqsNt5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@save',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::3zwD6P69zdIqsNt5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LOkZXiDpJmHhFauL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@list',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::LOkZXiDpJmHhFauL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oFZUSK26g6JlZh0I' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@single',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::oFZUSK26g6JlZh0I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hIG4UNFzgm196m4O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@update',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::hIG4UNFzgm196m4O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DpUuxuFSaijxcUw9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@delete',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::DpUuxuFSaijxcUw9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tMAVmXrwfioIJqgO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/expense/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenseController@approve',
        'controller' => 'App\\Http\\Controllers\\ExpenseController@approve',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/expense',
        'where' => 
        array (
        ),
        'as' => 'generated::tMAVmXrwfioIJqgO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RisnU6KgD87CSs8H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@save',
        'controller' => 'App\\Http\\Controllers\\TankController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::RisnU6KgD87CSs8H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bd3zQXvhnU9Vxvt7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@list',
        'controller' => 'App\\Http\\Controllers\\TankController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::bd3zQXvhnU9Vxvt7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xB4xkqBsb5Ks9gg2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@single',
        'controller' => 'App\\Http\\Controllers\\TankController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::xB4xkqBsb5Ks9gg2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9Y6J3RGoh2pk6xuN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@update',
        'controller' => 'App\\Http\\Controllers\\TankController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::9Y6J3RGoh2pk6xuN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qKi6sHu9mQhdlluv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@delete',
        'controller' => 'App\\Http\\Controllers\\TankController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::qKi6sHu9mQhdlluv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xtbAwi5aFOS2wFyR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/get/nozzle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@getNozzle',
        'controller' => 'App\\Http\\Controllers\\TankController@getNozzle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::xtbAwi5aFOS2wFyR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lffeCqUjUNGFR5B3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/byProduct',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@getTankByProduct',
        'controller' => 'App\\Http\\Controllers\\TankController@getTankByProduct',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::lffeCqUjUNGFR5B3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VWmwmpANPF0UhoMZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/getVolume',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@getVolume',
        'controller' => 'App\\Http\\Controllers\\TankController@getVolume',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::VWmwmpANPF0UhoMZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i45VQXaTeWUtBeOG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/getBstiChart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@getBstiChart',
        'controller' => 'App\\Http\\Controllers\\TankController@getBstiChart',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank',
        'where' => 
        array (
        ),
        'as' => 'generated::i45VQXaTeWUtBeOG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kMzZ1xhP7BhEoYvO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingSave',
        'controller' => 'App\\Http\\Controllers\\TankController@readingSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::kMzZ1xhP7BhEoYvO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h3JzMiEp6sFtvP5c' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingList',
        'controller' => 'App\\Http\\Controllers\\TankController@readingList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::h3JzMiEp6sFtvP5c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VQUuapKgzcBHVi6N' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingSingle',
        'controller' => 'App\\Http\\Controllers\\TankController@readingSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::VQUuapKgzcBHVi6N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kE9h50lLJzRWsGUq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingUpdate',
        'controller' => 'App\\Http\\Controllers\\TankController@readingUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::kE9h50lLJzRWsGUq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lBRXpZ7YctkxddO8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@readingDelete',
        'controller' => 'App\\Http\\Controllers\\TankController@readingDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::lBRXpZ7YctkxddO8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IlP9Oi9TobRdN5Wx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/reading/latest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@latestReading',
        'controller' => 'App\\Http\\Controllers\\TankController@latestReading',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/reading',
        'where' => 
        array (
        ),
        'as' => 'generated::IlP9Oi9TobRdN5Wx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AQtcQKodEPZdZ6Vt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillSave',
        'controller' => 'App\\Http\\Controllers\\TankController@refillSave',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::AQtcQKodEPZdZ6Vt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XZ4ox848EPLzOhRm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillList',
        'controller' => 'App\\Http\\Controllers\\TankController@refillList',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::XZ4ox848EPLzOhRm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lcSgK4Fmy8wRWRpa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillSingle',
        'controller' => 'App\\Http\\Controllers\\TankController@refillSingle',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::lcSgK4Fmy8wRWRpa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tU8hJurInd7vH6ZI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillUpdate',
        'controller' => 'App\\Http\\Controllers\\TankController@refillUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::tU8hJurInd7vH6ZI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m27RRjP6h272DLjq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/tank/refill/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\TankController@refillDelete',
        'controller' => 'App\\Http\\Controllers\\TankController@refillDelete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/tank/refill',
        'where' => 
        array (
        ),
        'as' => 'generated::m27RRjP6h272DLjq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0K6dTaiexlYlqegM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@save',
        'controller' => 'App\\Http\\Controllers\\BankController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::0K6dTaiexlYlqegM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1pEzM5tD76mATFpN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@list',
        'controller' => 'App\\Http\\Controllers\\BankController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::1pEzM5tD76mATFpN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jXbhMbGRtMjoonHw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@single',
        'controller' => 'App\\Http\\Controllers\\BankController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::jXbhMbGRtMjoonHw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hZbLMpwl2TyH5jR4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@update',
        'controller' => 'App\\Http\\Controllers\\BankController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::hZbLMpwl2TyH5jR4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QeDgLTvSrwBhBRVi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/bank/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BankController@delete',
        'controller' => 'App\\Http\\Controllers\\BankController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/bank',
        'where' => 
        array (
        ),
        'as' => 'generated::QeDgLTvSrwBhBRVi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cYixQitSbtBqr5yv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@save',
        'controller' => 'App\\Http\\Controllers\\VendorController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::cYixQitSbtBqr5yv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KaXLrgNT0Mt3lS9U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@list',
        'controller' => 'App\\Http\\Controllers\\VendorController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::KaXLrgNT0Mt3lS9U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mYjSJJLSrWDO9CTM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@single',
        'controller' => 'App\\Http\\Controllers\\VendorController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::mYjSJJLSrWDO9CTM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4gB4cxtQWxGtT8o9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@update',
        'controller' => 'App\\Http\\Controllers\\VendorController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::4gB4cxtQWxGtT8o9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hXaIg4cg1aMDjHDZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/vendor/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VendorController@delete',
        'controller' => 'App\\Http\\Controllers\\VendorController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/vendor',
        'where' => 
        array (
        ),
        'as' => 'generated::hXaIg4cg1aMDjHDZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::StbLYI1Y69AwfTYo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@save',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::StbLYI1Y69AwfTYo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::274yFdXhqvzgmucT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@list',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::274yFdXhqvzgmucT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IAXFKnMS3OJ9bLof' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@single',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::IAXFKnMS3OJ9bLof',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::W97Ko5Kb9ATvpxIB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@update',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::W97Ko5Kb9ATvpxIB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::orYIXuTpfgtzuudD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@delete',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::orYIXuTpfgtzuudD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uiSkz7R0nmCj2KM3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/latest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@latest',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@latest',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::uiSkz7R0nmCj2KM3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8B6WA6jf7PVBVmkl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/pay/order/quantity',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PayOrderController@getQuantity',
        'controller' => 'App\\Http\\Controllers\\PayOrderController@getQuantity',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/pay/order',
        'where' => 
        array (
        ),
        'as' => 'generated::8B6WA6jf7PVBVmkl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Xf60intCZABXF4q6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@save',
        'controller' => 'App\\Http\\Controllers\\SaleController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::Xf60intCZABXF4q6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dHfdDG3hWkQrmVMb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@list',
        'controller' => 'App\\Http\\Controllers\\SaleController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::dHfdDG3hWkQrmVMb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FAAcpvC6eAZYU8vy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@single',
        'controller' => 'App\\Http\\Controllers\\SaleController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::FAAcpvC6eAZYU8vy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::46PzbGgTE8YPlYKx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@update',
        'controller' => 'App\\Http\\Controllers\\SaleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::46PzbGgTE8YPlYKx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4ap1iycp3KBnXW9p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@delete',
        'controller' => 'App\\Http\\Controllers\\SaleController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::4ap1iycp3KBnXW9p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::adYGzTAIafTUAEW1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/unauthorizedBill',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@unauthorizedBill',
        'controller' => 'App\\Http\\Controllers\\SaleController@unauthorizedBill',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::adYGzTAIafTUAEW1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RHv1UJxXh5OlYN8z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/sale/unauthorizedBill/transfer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@unauthorizedBillTransfer',
        'controller' => 'App\\Http\\Controllers\\SaleController@unauthorizedBillTransfer',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/sale',
        'where' => 
        array (
        ),
        'as' => 'generated::RHv1UJxXh5OlYN8z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L7GLlpjDsCnjnlRg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@save',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::L7GLlpjDsCnjnlRg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IeQ2FnGPLbhhfwVe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@list',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::IeQ2FnGPLbhhfwVe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AZYswNQ2koWaJLbI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@single',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::AZYswNQ2koWaJLbI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SFs1Hl2oGgIWOIbH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@update',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::SFs1Hl2oGgIWOIbH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7p9G57Da2EtEms08' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/creditCompany/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CreditCompanyController@delete',
        'controller' => 'App\\Http\\Controllers\\CreditCompanyController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/creditCompany',
        'where' => 
        array (
        ),
        'as' => 'generated::7p9G57Da2EtEms08',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MO1cEwGRUzybTG5B' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@save',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::MO1cEwGRUzybTG5B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MElopi6dtTyzBCCE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@list',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::MElopi6dtTyzBCCE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d3fwDLFSQLd1eJcc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@single',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::d3fwDLFSQLd1eJcc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NEQrIqrg1GhTHHeW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@update',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::NEQrIqrg1GhTHHeW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8qoCvgCX1a1PE6iT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/posMachine/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PosMachineController@delete',
        'controller' => 'App\\Http\\Controllers\\PosMachineController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/posMachine',
        'where' => 
        array (
        ),
        'as' => 'generated::8qoCvgCX1a1PE6iT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8Z9CZNw6sQEj5ozG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@save',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::8Z9CZNw6sQEj5ozG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FBa3WqXlxoRzze5U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@list',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::FBa3WqXlxoRzze5U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tVUbiXRDIuul47Ci' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@single',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::tVUbiXRDIuul47Ci',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e9t4sNPHJeogSHTg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@update',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::e9t4sNPHJeogSHTg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t7GTBqrtC10bHeVC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/employee/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\EmployeeController@delete',
        'controller' => 'App\\Http\\Controllers\\EmployeeController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/employee',
        'where' => 
        array (
        ),
        'as' => 'generated::t7GTBqrtC10bHeVC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sGhN5LBjAuhGH8Wy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/searchEmployee',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@searchEmployee',
        'controller' => 'App\\Http\\Controllers\\SalaryController@searchEmployee',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::sGhN5LBjAuhGH8Wy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KuhWOyskjnBXqFkg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@save',
        'controller' => 'App\\Http\\Controllers\\SalaryController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::KuhWOyskjnBXqFkg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MrYa8ZSbqoI1vsTL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@list',
        'controller' => 'App\\Http\\Controllers\\SalaryController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::MrYa8ZSbqoI1vsTL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gR8sjttAUdcnZXET' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@single',
        'controller' => 'App\\Http\\Controllers\\SalaryController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::gR8sjttAUdcnZXET',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0bBw2R7uumrI7PUm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@update',
        'controller' => 'App\\Http\\Controllers\\SalaryController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::0bBw2R7uumrI7PUm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QGNVh5oCb2Et39kr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@delete',
        'controller' => 'App\\Http\\Controllers\\SalaryController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::QGNVh5oCb2Et39kr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y1DU2pHmOn2txhkD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/getCategory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@getCategory',
        'controller' => 'App\\Http\\Controllers\\SalaryController@getCategory',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::y1DU2pHmOn2txhkD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RHZ17fk9gvFVEQUK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/salary/print',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SalaryController@print',
        'controller' => 'App\\Http\\Controllers\\SalaryController@print',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/salary',
        'where' => 
        array (
        ),
        'as' => 'generated::RHZ17fk9gvFVEQUK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ucK4ll9DBz6noEPo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/companySale/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\SaleController@getCompanySale',
        'controller' => 'App\\Http\\Controllers\\SaleController@getCompanySale',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/companySale',
        'where' => 
        array (
        ),
        'as' => 'generated::ucK4ll9DBz6noEPo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7PQpt26EOSHbJNvy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@generate',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@generate',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::7PQpt26EOSHbJNvy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Kq5RRfHoayOjjCpk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@list',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::Kq5RRfHoayOjjCpk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0zhX4XquCiSUZqmu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/payment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@payment',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@payment',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::0zhX4XquCiSUZqmu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Wq8xaK5VxWMfPSTI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/global/payment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@globalPayment',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@globalPayment',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::Wq8xaK5VxWMfPSTI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IHSchNIrSLmuMqdD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@delete',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::IHSchNIrSLmuMqdD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7XKFZ62LFtnPx1nV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@single',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::7XKFZ62LFtnPx1nV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B0ygOp889vhmr8fk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/invoice/download/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\InvoiceController@downloadPdf',
        'controller' => 'App\\Http\\Controllers\\InvoiceController@downloadPdf',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/invoice',
        'where' => 
        array (
        ),
        'as' => 'generated::B0ygOp889vhmr8fk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MWJILjmHxRg5Xvj3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/dashboard/get',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@get',
        'controller' => 'App\\Http\\Controllers\\DashboardController@get',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/dashboard',
        'where' => 
        array (
        ),
        'as' => 'generated::MWJILjmHxRg5Xvj3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZHXtmCftTVSJcYoS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/report/dailyLog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@dailyLog',
        'controller' => 'App\\Http\\Controllers\\ReportController@dailyLog',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/report/dailyLog',
        'where' => 
        array (
        ),
        'as' => 'generated::ZHXtmCftTVSJcYoS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0zq2RbyebbKufirb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/report/dailyLog/export/pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@dailyLogExportPdf',
        'controller' => 'App\\Http\\Controllers\\ReportController@dailyLogExportPdf',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/report/dailyLog',
        'where' => 
        array (
        ),
        'as' => 'generated::0zq2RbyebbKufirb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RAyMqnZjEw0CU6v7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/report/sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@salesReport',
        'controller' => 'App\\Http\\Controllers\\ReportController@salesReport',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/report',
        'where' => 
        array (
        ),
        'as' => 'generated::RAyMqnZjEw0CU6v7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gEk6XaUsrS1cQRMB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/user/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@save',
        'controller' => 'App\\Http\\Controllers\\UserController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/user',
        'where' => 
        array (
        ),
        'as' => 'generated::gEk6XaUsrS1cQRMB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6XbFnPxEhfvLvbgC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/user/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@list',
        'controller' => 'App\\Http\\Controllers\\UserController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/user',
        'where' => 
        array (
        ),
        'as' => 'generated::6XbFnPxEhfvLvbgC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7GWeDUzxwdiaJCzM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/user/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@single',
        'controller' => 'App\\Http\\Controllers\\UserController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/user',
        'where' => 
        array (
        ),
        'as' => 'generated::7GWeDUzxwdiaJCzM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OCGChP3Ex4uBgAy6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/user/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/user',
        'where' => 
        array (
        ),
        'as' => 'generated::OCGChP3Ex4uBgAy6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IdGg0CKZPxxU3WDM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/user/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete',
        'controller' => 'App\\Http\\Controllers\\UserController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/user',
        'where' => 
        array (
        ),
        'as' => 'generated::IdGg0CKZPxxU3WDM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l5ZmhlhJLvVGka85' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balanceTransfer/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceTransferController@save',
        'controller' => 'App\\Http\\Controllers\\BalanceTransferController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balanceTransfer',
        'where' => 
        array (
        ),
        'as' => 'generated::l5ZmhlhJLvVGka85',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m9D1Hmy7SMeR5EGY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balanceTransfer/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceTransferController@list',
        'controller' => 'App\\Http\\Controllers\\BalanceTransferController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balanceTransfer',
        'where' => 
        array (
        ),
        'as' => 'generated::m9D1Hmy7SMeR5EGY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0rES6xCZDB7ON9wH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balanceTransfer/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceTransferController@single',
        'controller' => 'App\\Http\\Controllers\\BalanceTransferController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balanceTransfer',
        'where' => 
        array (
        ),
        'as' => 'generated::0rES6xCZDB7ON9wH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mQluNUlPgARNjwaR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balanceTransfer/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceTransferController@update',
        'controller' => 'App\\Http\\Controllers\\BalanceTransferController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balanceTransfer',
        'where' => 
        array (
        ),
        'as' => 'generated::mQluNUlPgARNjwaR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fUr9fvL5M5sCjLrn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balanceTransfer/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceTransferController@approve',
        'controller' => 'App\\Http\\Controllers\\BalanceTransferController@approve',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balanceTransfer',
        'where' => 
        array (
        ),
        'as' => 'generated::fUr9fvL5M5sCjLrn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JcGs6LbEf7if5Fen' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/balanceTransfer/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\BalanceTransferController@delete',
        'controller' => 'App\\Http\\Controllers\\BalanceTransferController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/balanceTransfer',
        'where' => 
        array (
        ),
        'as' => 'generated::JcGs6LbEf7if5Fen',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eHXkzpmZP1C6IvUe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/company/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CompanyController@save',
        'controller' => 'App\\Http\\Controllers\\CompanyController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/company',
        'where' => 
        array (
        ),
        'as' => 'generated::eHXkzpmZP1C6IvUe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yUlIKpGEHFPZz5sh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/company/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CompanyController@single',
        'controller' => 'App\\Http\\Controllers\\CompanyController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/company',
        'where' => 
        array (
        ),
        'as' => 'generated::yUlIKpGEHFPZz5sh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jwjEUwbyO0hugrmv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/voucher/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VoucherController@save',
        'controller' => 'App\\Http\\Controllers\\VoucherController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/voucher',
        'where' => 
        array (
        ),
        'as' => 'generated::jwjEUwbyO0hugrmv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KR4ONfReMZwSaU0s' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/voucher/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\VoucherController@list',
        'controller' => 'App\\Http\\Controllers\\VoucherController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/voucher',
        'where' => 
        array (
        ),
        'as' => 'generated::KR4ONfReMZwSaU0s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nnDdm4hrcKVKFFmz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/driver/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DriverController@save',
        'controller' => 'App\\Http\\Controllers\\DriverController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/driver',
        'where' => 
        array (
        ),
        'as' => 'generated::nnDdm4hrcKVKFFmz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dnnar7wL6jdXWIOH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/driver/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DriverController@list',
        'controller' => 'App\\Http\\Controllers\\DriverController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/driver',
        'where' => 
        array (
        ),
        'as' => 'generated::dnnar7wL6jdXWIOH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7YWVpq6b1twuhawh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/driver/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DriverController@single',
        'controller' => 'App\\Http\\Controllers\\DriverController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/driver',
        'where' => 
        array (
        ),
        'as' => 'generated::7YWVpq6b1twuhawh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DdLBM61UcV4yKeXb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/driver/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DriverController@update',
        'controller' => 'App\\Http\\Controllers\\DriverController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/driver',
        'where' => 
        array (
        ),
        'as' => 'generated::DdLBM61UcV4yKeXb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2gFvFSS7b3Vs8NeL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/driver/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DriverController@delete',
        'controller' => 'App\\Http\\Controllers\\DriverController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/driver',
        'where' => 
        array (
        ),
        'as' => 'generated::2gFvFSS7b3Vs8NeL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dXk3PgYHgNRlQyE4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/driver/amount',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\DriverController@getAmount',
        'controller' => 'App\\Http\\Controllers\\DriverController@getAmount',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/driver',
        'where' => 
        array (
        ),
        'as' => 'generated::dXk3PgYHgNRlQyE4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2Bx4dKv92QYThKgm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/role/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@list',
        'controller' => 'App\\Http\\Controllers\\RoleController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/role',
        'where' => 
        array (
        ),
        'as' => 'generated::2Bx4dKv92QYThKgm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LW30pAMpuNsSCKzP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/role/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@save',
        'controller' => 'App\\Http\\Controllers\\RoleController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/role',
        'where' => 
        array (
        ),
        'as' => 'generated::LW30pAMpuNsSCKzP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yc9CnpVieVCKfbEo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/role/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@single',
        'controller' => 'App\\Http\\Controllers\\RoleController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/role',
        'where' => 
        array (
        ),
        'as' => 'generated::yc9CnpVieVCKfbEo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zaKtlNGwa7dnp5AY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/role/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\RoleController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/role',
        'where' => 
        array (
        ),
        'as' => 'generated::zaKtlNGwa7dnp5AY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RhmBDGvswnRix2zf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/role/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\RoleController@delete',
        'controller' => 'App\\Http\\Controllers\\RoleController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/role',
        'where' => 
        array (
        ),
        'as' => 'generated::RhmBDGvswnRix2zf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::elcGY3BfF6lVXRdP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/permission/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\PermissionController@getAllPermission',
        'controller' => 'App\\Http\\Controllers\\PermissionController@getAllPermission',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/permission',
        'where' => 
        array (
        ),
        'as' => 'generated::elcGY3BfF6lVXRdP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PartApB4rw0EicWb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/fuelAdjustment/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\FuelAdjustmentController@save',
        'controller' => 'App\\Http\\Controllers\\FuelAdjustmentController@save',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/fuelAdjustment',
        'where' => 
        array (
        ),
        'as' => 'generated::PartApB4rw0EicWb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eSlJSUek5NFw863j' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/fuelAdjustment/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\FuelAdjustmentController@list',
        'controller' => 'App\\Http\\Controllers\\FuelAdjustmentController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/fuelAdjustment',
        'where' => 
        array (
        ),
        'as' => 'generated::eSlJSUek5NFw863j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M97c1Em4cjKc3aPw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/fuelAdjustment/single',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\FuelAdjustmentController@single',
        'controller' => 'App\\Http\\Controllers\\FuelAdjustmentController@single',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/fuelAdjustment',
        'where' => 
        array (
        ),
        'as' => 'generated::M97c1Em4cjKc3aPw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TcgV60NYawjbxAZN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/fuelAdjustment/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\FuelAdjustmentController@update',
        'controller' => 'App\\Http\\Controllers\\FuelAdjustmentController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/fuelAdjustment',
        'where' => 
        array (
        ),
        'as' => 'generated::TcgV60NYawjbxAZN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Zq4IqrJlsoCa41G6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/fuelAdjustment/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\FuelAdjustmentController@delete',
        'controller' => 'App\\Http\\Controllers\\FuelAdjustmentController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/fuelAdjustment',
        'where' => 
        array (
        ),
        'as' => 'generated::Zq4IqrJlsoCa41G6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6xzY4IXn3vRfUV1X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/companyBill/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CompanyBillController@list',
        'controller' => 'App\\Http\\Controllers\\CompanyBillController@list',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/companyBill',
        'where' => 
        array (
        ),
        'as' => 'generated::6xzY4IXn3vRfUV1X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vqv9VtFOqq1Qumqs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/companyBill/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CompanyBillController@download',
        'controller' => 'App\\Http\\Controllers\\CompanyBillController@download',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/companyBill',
        'where' => 
        array (
        ),
        'as' => 'generated::vqv9VtFOqq1Qumqs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rgSCW9YyFFdkZi6E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1.0/car/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'AuthReqCheck',
        ),
        'uses' => 'App\\Http\\Controllers\\CarController@search',
        'controller' => 'App\\Http\\Controllers\\CarController@search',
        'namespace' => NULL,
        'prefix' => 'api/v1.0/car',
        'where' => 
        array (
        ),
        'as' => 'generated::rgSCW9YyFFdkZi6E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
