const Action= {
    CREATE : 'Create',
    EDIT : 'Edit',
    DELETE : 'Delete',
    VIEW : 'View',
}
export default Action
