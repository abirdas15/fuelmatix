<template>
    <div class="w-100">
        <div class="not-found">
            <div>
                <p class="error-status">404</p>
                <div class="error-msg">
                    <h5>Ooops!!</h5>
                    <p>That Page Doesn't Exist Or Is Unavailable.</p>
                </div>
                <button class="btn">Go Back to Home</button>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    components: {},
    data() {
        return {};
    },
};
</script>
