<?php

namespace App\Common;

class FuelMatixStatus
{
    const APPROVE = 'approve';
    const PENDING = 'pending';
    const COMPLETE = 'complete';
    const END = 'end';
}
