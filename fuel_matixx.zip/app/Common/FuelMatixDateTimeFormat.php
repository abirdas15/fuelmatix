<?php

namespace App\Common;

class FuelMatixDateTimeFormat
{
    const ONLY_DATE = 'Y-m-d';
    const STANDARD_DATE = 'd/m/Y';
    const STANDARD_DATE_TIME = 'd/m/Y h:iA';
}
