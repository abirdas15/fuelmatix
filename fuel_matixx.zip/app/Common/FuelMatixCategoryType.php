<?php

namespace App\Common;

class FuelMatixCategoryType
{
    const ASSET = 'assets';
    const LIABILITIES = 'liabilities';
    const EQUITY = 'equity';
    const EXPENSE = 'expenses';
    const INCOME = 'income';
}
