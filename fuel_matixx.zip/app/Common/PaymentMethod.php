<?php

namespace App\Common;

class PaymentMethod
{
    const CASH = 'cash';
    const CARD = 'card';
    const COMPANY = 'company';
}
